


window.onscroll = function() {
    if (isBottomOfPage()) {
        document.getElementById("scrollToTopBtn").style.display = "block";
        console.log("Bottom of the page reached!");
    }else {
        document.getElementById("scrollToTopBtn").style.display = "none";
      }
};


document.getElementById("scrollToTopBtn").addEventListener("click", function() {
//   scrollToTop();
setTimeout(scrollToTop, 500);
});



// function scrollToTop() {
//   document.body.scrollTop = 0;
//   document.documentElement.scrollTop = 0;
// }

function scrollToTop() {
    // Get the current scroll position
    var currentScroll = document.documentElement.scrollTop || document.body.scrollTop;
    
    // Calculate how far to scroll to reach the top
    var scrollStep = -currentScroll / 15;
    
    // Create a function to perform the scroll animation
    var scrollInterval = setInterval(function(){
      // Scroll by scrollStep amount
      window.scrollBy(0, scrollStep);
      // If we've reached the top of the page or scrolled past it, stop the interval
      if (document.documentElement.scrollTop <= 0 || document.body.scrollTop <= 0) {
        clearInterval(scrollInterval);
      }
    }, 85); 
  }





function isBottomOfPage() {
    var viewportHeight = window.innerHeight;

  
    var totalHeight = document.body.scrollHeight;

   
    var scrollPosition = window.scrollY || window.pageYOffset || document.documentElement.scrollTop;

   
    return (scrollPosition + viewportHeight) >= totalHeight;

}








// code for pop ups



document.addEventListener('DOMContentLoaded', function() {
  // Get the card element
  var cards = document.querySelectorAll('.card');



  cards.forEach(card => {
    card.addEventListener('click', function(event) {
        // Check if the click target is an icon
        if (event.target.closest('.tip2')) {
          // If clicked on an icon, set index to 1
          console.log("icon clicked");
          displayPopup(1);
        }else if(event.target.closest('.tip3')){
          displayPopup(3);
        }
         else {
          // If clicked anywhere else on the card, set index to 2
          displayPopup(2);
        }
      });
});


  // Add click event listener to the card
//   card.addEventListener('click', function(event) {
//     // Check if the click target is an icon
//     if (event.target.closest('.datainfo')) {
//       // If clicked on an icon, set index to 1
//       console.log("icon clicked");
//       displayPopup(1);
//     } else {
//       // If clicked anywhere else on the card, set index to 2
//       displayPopup(2);
//     }
//   });


  
  // Function to display the appropriate pop-up based on the index
  function displayPopup(index) {
    // Hide all pop-ups
    hidePopups();

    // Get the pop-up to display based on the index
    var popup;
    if (index === 1) {
      popup = document.getElementById('uploadPopup');
    } else if (index === 2) {
      popup = document.getElementById('defaultPopup');
    }else if (index === 3) {
      popup = document.getElementById('sharePopup');
    }

    // Display the selected pop-up
    if (popup) {
        console.log("pop up opened")
      popup.style.display = 'block';
      // Add event listener to close button within the pop-up
      var closeButton = popup.querySelector('.closeButton');
      if (closeButton) {
        
        console.log("if block enter")
        closeButton.addEventListener('click', function(e) {
            popup.style.display = 'none';
            e.stopPropagation();
        });

        

      }
    } else {
      console.error("Popup not found for index: " + index);
    }
  }

  // Function to hide all pop-ups
  function hidePopups() {
    console.log("hide clicked")
    var popups = document.querySelectorAll('.popup');
    popups.forEach(function(popup) {
      popup.style.display = 'none';
    });
  }

 

});

  
  


// uploading images


// const openPopupBtn = document.getElementById('openPopupBtn');
// const customPopup = document.getElementById('customPopup');
const fileInput = document.getElementById('fileInput');
const progressBar = document.getElementById('progressBar');

// openPopupBtn.addEventListener('click', () => {
//   customPopup.style.display = 'block';
// });

// function closePopup() {
//   customPopup.style.display = 'none';
// }

let files = [];

fileInput.addEventListener('change', (event) => {
   files = event.target.files;
  if (files.length === 0) return;

  console.log(files.length)

  const totalSize = Array.from(files).reduce((acc, file) => acc + file.size, 0);

  let loaded = 0;

  const reader = new FileReader();

  reader.onload = () => {
    console.log("onload render entered")
    loaded += reader.result.length;
    const progress = (loaded / totalSize) * 100;
    progressBar.style.width = progress + '%';

    if (loaded < totalSize) {
      reader.readAsDataURL(files[0]);
    } else {
      // All files loaded
      const images = Array.from(files).map(file => reader.result);
      console.log(images); // You can use this array of images as needed
    }
  };

  reader.readAsDataURL(files[0]);
});

  





// image uploading popup and gallary code



// let files = [];
let totalSizeKB = 0;
let numone = 1;

selection = document.querySelector('.selection'),
uploadButton = document.querySelector('.top button'),
gallarybutton = document.querySelector('.bottom button[type="button2"]'),
form = document.querySelector('form'),
imagepreview = document.querySelector('.imagepreview'),
size = document.querySelector('.size'),
NoOfMedia = document.querySelector('.NoOfMedia'),
text = document.querySelector('.inner'),
browse = document.querySelector('.select'),
input = document.querySelector('form input');





browse.addEventListener('click',() => input.click());

// input change event




input.addEventListener('change',() => {
    let file = input.files;

    for (let i = 0; i < file.length; i++){
        if(files.every(e => e.name !== file[i].name )) files.push(file[i])
        
    }
console.log(files)
    form.reset();
    updateTotalSize();
    console.log(files)
    showImages();
})



const updateTotalSize = () => {
  totalSizeKB = 0;
  files.forEach((e) => {
      totalSizeKB += e.size / 1024; 
  });
};


const delImage = index =>{
    files.splice(index,1)
    showImages()
}



const showImages = () => {
    let images = '';
    let totalSize = 0; 

    console.log(files)
    files.forEach((e, i) => {
        images += `<div class="image">
            <img src="${URL.createObjectURL(e)}" alt="image">
            <span onclick="delImage(${i})">&times;</span>
        </div>`;

        totalSize += e.size;
    });

    // Convert bytes to kilobytes for readability
    let totalSizeKB = totalSize / 1024/1024;
    let NoOfMedia = files.length;

    console.log(totalSizeKB)
    console.log(files.length)
    console.log(NoOfMedia)


    imagepreview.innerHTML = images;
    NoOfMedia = document.querySelector('.NoOfMedia'),

    // Display total size and number

    size.innerHTML = `Total Size: ${totalSizeKB.toFixed(2)} MB`; 
    NoOfMedia.innerHTML = `Total No Of Media Selected: ${files.length}`; 
   
    console.log(files)
    
};




// drag and drop


form.addEventListener('dragover',e => {
    e.preventDefault()

    form.classList.add('dragover')
    text.innerHTML = 'Drop images here'
})

form.addEventListener('dragleave',e => {
    e.preventDefault()

    form.classList.remove('dragover')
    text.innerHTML = `Drag & Drop images here or
    <span class="select" >   Browse</span>

</span>`
})



form.addEventListener('drop',e =>{
    e.preventDefault()


    form.classList.remove('dragover')
    text.innerHTML = `Drag & Drop images here or
    <span class="select" >   Browse</span>
</span>`

    let file = e.dataTransfer.files;
    for (let i = 0; i < file.length; i++){
        if(files.every(e => e.name !== file[i].name )) files.push(file[i])
        
    }
console.log("script added")
    form.reset();
    showImages();
})






console.log(files)


uploadButton.addEventListener('click', () => {

  console.log(files)
  uploadtolclstrg(files)
  // Simulate upload process
  let uploadProgress = 0;
  
  console.log("upload button clicked")
  const interval = setInterval(() => {
      uploadProgress += totalSizeKB / 100; 

      updateProgressBar(uploadProgress);

      if (uploadProgress >= totalSizeKB) {
          console.log("function interval disabled")
          clearInterval(interval);
          progressBar.style.display = 'none';

         
          setTimeout(() => {

            progressBar.style.display = 'none';
              const element = document.querySelector('.alert');
              // element.classList.add('show');
              element.style.display = 'block';
          }, 2000);

          setTimeout(() => {
              displayGallery();
          }, 7000);
      }
  }, 80);
});






const updateProgressBar = (progress) => {
    console.log("function updateprogress bar invoked")
    const progressBar = document.querySelector('.progress-bar');
    const gallery = document.querySelector('.gallery');
    gallery.style.display = `block`;
    selection.style.display = `none`;
    progressBar.style.width = `${(progress/totalSizeKB)*100}%`;
};

// files.forEach((file,i) => {
//     galleryHTML += `<div class="image" style="width: 30%;height: 100%;">
//         <img src="${URL.createObjectURL(file)}" alt="image" style="width: 100%;height: 100%;">
//     </div>`;
// });

// galleryDiv.innerHTML = galleryHTML;

const uploadtolclstrg = (files)=>{
  console.log(files)
  // fileInput  = document.querySelector('form input');
  input2  = document.querySelector('form input');
  console.log("Attempting to store files in localStorage...");

  // const input = document.getElementById('fileInput'); // Make sure this correctly references your file input element
  
  // const files = input2.files;
  console.log(files)
  console.log("Files retrieved:", files);
  
  const fileArray = Array.from(files).map(file => ({
      name: file.name,
      size: file.size,
      type: file.type,
      lastModified: file.lastModified
  }));
  
  console.log("File array:", fileArray);
  
  localStorage.setItem('uploadedFiles', JSON.stringify(fileArray));
  console.log("Files stored in localStorage:", localStorage.getItem('uploadedFiles'));
}

const displayGallery = () => {
  const popup = document.querySelector('.popup');
  popup.style.display = 'none';

    console.log(files)
    console.log(numone)

 window.location.href = 'Gallary.html';
 console.log(files)
 console.log(numone)
 let galleryHTML = '';
 const galleryDiv = document.querySelector('.imagesgallary');
 const old = document.querySelector('.old');

 old.style.display = 'none';


 files.forEach((file,i) => {
  galleryHTML += `<div class="image" style="width: 30%;height: 100%;">
      <img src="${URL.createObjectURL(file)}" alt="image" style="width: 100%;height: 100%;">
      <h1>file.name</h1>
  </div>`;
});

galleryDiv.innerHTML = galleryHTML;
// window.location.href = 'Gallary.html';
 
};


// gallarybutton.addEventListener('click', () => {
//   console.log("gallary view cliked")
//   updateProgressBar(uploadProgress);
// })


